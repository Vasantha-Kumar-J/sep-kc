﻿using System.Text.RegularExpressions;
using System.Xml.Linq;
using ConsoleTables;

namespace EmployeeManagement
{
    /// <summary>
    /// Contains functions to manage the employee list
    /// </summary>
    internal class EmployeeManager
    {
        private Utility _utility = new Utility();
        private Logger _logger = new Logger();
        public List<Employee> AddEmployee(List<Employee> employees)
        {
            var employee = new Employee();
            Console.WriteLine("Enter name of the Employee:");
            employee.Name = _utility.GetValidName();
            Console.WriteLine("Enter working hours of the employee:");
            employee.WorkingHours = _utility.GetValidHours();
            Console.WriteLine("Choose the skills of the employee:");
            employee.Skills = _utility.GetSkill();
            Console.WriteLine("Enter availability of the employee");
            employee.Availability = _utility.GetAvailability();
            if (!employees.Contains(employee))
            {
                employees.Add(employee);
                return employees;
            }
            Console.WriteLine("Employee is already present");
            return employees;
        }
        public List<Employee> ImportEmployeeList(List<Employee> employees)
        {
            Console.WriteLine("Enter file path to get employee list");
            var filePath = _utility.GetValidFilePath();
            try
            {
                using (var streamReader = new StreamReader(filePath))
                {
                    string content = streamReader.ReadToEnd();
                    string[] array = content.Split('\n');
                    foreach (string item in array)
                    {
                        string[] employeeDetail = item.Split(' ');
                        var employee = new Employee();
                        int.TryParse(employeeDetail[0],out int id);
                        employee.Id = id;
                        employee.Name = employeeDetail[1];
                        float.TryParse(employeeDetail[2],out float workingHours);
                        employee.WorkingHours = workingHours;
                        employee.Skills = employeeDetail[3];
                        bool.TryParse(employeeDetail[4],out bool availablity);
                        employee.Availability= availablity;
                        employees.Add(employee);
                    }
                    _logger.LogMessage($"Employee List updated{DateTime.Now}");
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception.Message);
                _logger.LogMessage(exception.Message);
            }
            return employees;
        }
        public void ExportEmployeeDetails(List<Employee> employees)
        {
            var Table = new ConsoleTable("Id", "Name", "WorkingHours", "Skills", "Availability");
            foreach(var employee in employees)
            {
                Table.AddRow(employee.Id,employee.Name,employee.WorkingHours,employee.Skills,employee.Availability);
            }
            Console.WriteLine("Enter file path to export the content:");
            string filePath = _utility.GetValidFilePath();
            using (var writer = new StreamWriter(filePath))
            {
                writer.Write(Table);
            }
        }
    }
}