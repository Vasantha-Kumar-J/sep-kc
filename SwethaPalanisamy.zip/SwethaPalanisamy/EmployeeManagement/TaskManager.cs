﻿using ConsoleTables;
using System.Dynamic;
using System.Text.RegularExpressions;

namespace EmployeeManagement
{
    /// <summary>
    /// Contains functions to manage the task list
    /// </summary>
    internal class TaskManager
    {
        private Utility _utility = new Utility();
        private Logger _logger = new Logger();
        public List<Task> AddTask(List<Task> tasks)
        {
            var task = new Task();
            Console.WriteLine("Enter Task id");
            task.Id = _utility.GetInteger();
            Console.WriteLine("Enter description of the Task:");
            task.Description = Console.ReadLine();
            Console.WriteLine("Enter required hours of the task:");
            task.RequiredHours = _utility.GetValidHours();
            Console.WriteLine("Choose the skills required for the task:");
            task.SkillsRequired = _utility.GetSkill();
            Console.WriteLine("Enter dead line of the task");
            task.DeadLine = _utility.GetValidDate();
            if (!tasks.Contains(task))
            {
                tasks.Add(task);
                return tasks;
            }
            Console.WriteLine("Task is already present in the list");
            return tasks;
        }
        public List<Task> ImportTaskList(List<Task> tasks)
        {
            Console.WriteLine("Enter file path to get Task list");
            var filePath = _utility.GetValidFilePath();
            try
            {
                using (var streamReader = new StreamReader(filePath))
                {
                    string content = streamReader.ReadToEnd();
                    string[] array = content.Split('\n');
                    foreach (string item in array)
                    {
                        string[] taskDetail = item.Split(' ');
                        var task = new Task();
                        int.TryParse(taskDetail[0], out int id);
                        task.Id = id;
                        task.Description = taskDetail[1];
                        task.SkillsRequired = taskDetail[2];
                        float.TryParse(taskDetail[3], out float workingHours);
                        task.RequiredHours = workingHours;
                        DateTime.TryParse(taskDetail[4], out DateTime deadLine);
                        task.DeadLine = deadLine;
                        tasks.Add(task);
                    }
                    _logger.LogMessage($"Task List updated {DateTime.Now}");
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception.Message);
                _logger.LogMessage(exception.Message);
            }
            return tasks;
        }
        public void ExportTaskDetails(List<Task> tasks)
        {
            var Table = new ConsoleTable("Id", "Description", "SkillsRequired", "RequiredHours", "DeadLine");
            foreach (var task in tasks)
            {
                Table.AddRow(task.Id, task.Description, task.SkillsRequired, task.RequiredHours, task.DeadLine);
            }
            Console.WriteLine("Enter file path to export the content:");
            string filePath = _utility.GetValidFilePath();
            using(var writer = new StreamWriter(filePath))
            {
                writer.Write(Table);
            }
        }
    }
}
