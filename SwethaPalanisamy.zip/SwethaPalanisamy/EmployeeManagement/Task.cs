﻿namespace EmployeeManagement
{
    class Task
    {
        public int Id { get; set; }
        public string Description { get; set; }

        public string SkillsRequired { get; set; }

        public float RequiredHours { get; set; }

        public DateTime DeadLine { get; set; }
    }
}