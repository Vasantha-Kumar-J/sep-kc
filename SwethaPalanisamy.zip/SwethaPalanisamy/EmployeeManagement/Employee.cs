﻿using System.Text.RegularExpressions;

namespace EmployeeManagement
{
    /// <summary>
    /// Contains information about the employee
    /// </summary>
    class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public float WorkingHours { get; set; }
        public string Skills { get; set; }
        public bool Availability { get; set; }
    }

}