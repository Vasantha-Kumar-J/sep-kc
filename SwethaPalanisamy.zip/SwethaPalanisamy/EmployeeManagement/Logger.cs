﻿namespace EmployeeManagement
{
    /// <summary>
    /// Contains methods to log messages.
    /// </summary>
    internal class Logger
    {
        public void LogMessage(string message)
        {
            using (var writer = new StreamWriter(".\\.\\.\\.\\.\\.\\Log.txt"))
            {
                writer.WriteLine(message);
            }
        }
        public void DisplayLog()
        {
            using (var reader = new StreamReader(".\\.\\.\\.\\.\\.\\Log.txt"))
            {
               Console.WriteLine(reader.ReadToEnd());
            }
        }
    }
}