﻿using System.Text.RegularExpressions;

namespace EmployeeManagement
{
    /// <summary>
    /// Contains utility functions
    /// </summary>
    internal class Utility
    {
        /// <summary>
        /// Gets valid integer from the user
        /// </summary>
        /// <returns>Valid integer</returns>
        public int GetInteger()
        {
            int number;
            while (!int.TryParse(Console.ReadLine(), out number))
            {
                Console.WriteLine("Enter valid number");
            }
            return number;
        }

        /// <summary>
        /// Gets valid name from the user
        /// </summary>
        /// <returns>Valid name</returns>
        public string GetValidName()
        {
            string name = Console.ReadLine();
            var isNameValid = new Regex("[A-Za-z\\s]");
            if (!isNameValid.IsMatch(name))
            {
                Console.WriteLine("Enter valid name");
                GetValidName();
            }
            return name;
        }
        /// <summary>
        /// Gets Skill from the user
        /// </summary>
        /// <returns>skill</returns>
        public string GetSkill()
        {
            Console.WriteLine("1-Coding\n2-Design\n3-Testing");
            switch (GetInteger())
            {
                case 1:
                    return "coding";
                case 2:
                    return "design";
                case 3:
                    return "testing";
                default:
                    Console.WriteLine("Enter only available options");
                    return GetSkill();
            }
        }
        /// <summary>
        /// Gets valid hours from the user
        /// </summary>
        /// <returns>Valid hours</returns>
        public float GetValidHours()
        {
            float workingHours;
            while (!float.TryParse(Console.ReadLine(), out workingHours))
            {
                Console.WriteLine("Enter valid Hours");
            }
            return workingHours;
        }
        /// <summary>
        /// Gets availability of the employee from the user
        /// </summary>
        /// <returns>availability</returns>
        public bool GetAvailability()
        {
            Console.WriteLine("1-Available\n2-Unavailable");
            switch (GetInteger())
            {
                case 1:
                    return true;
                case 2:
                    return false;
                default:
                    Console.WriteLine("Enter only available options");
                    return GetAvailability();
            }
        }
        /// <summary>
        /// Gets date and time from the user
        /// </summary>
        /// <returns>date and time</returns>
        public DateTime GetValidDate()
        {
            DateTime deadLine;
            while (!DateTime.TryParse(Console.ReadLine(), out deadLine))
            {
                Console.WriteLine("Enter valid Hours");
            }
            return deadLine;
        }
        /// <summary>
        /// Gets valid file path from the user
        /// </summary>
        /// <returns>valid file path</returns>
        public string GetValidFilePath()
        {
            string filePath = Console.ReadLine();
            if (!File.Exists(filePath))
            {
                Console.WriteLine("Enter valid file path");
                GetValidFilePath();
            }
            return filePath;
        }
    }
}