﻿using System.Security.Cryptography.X509Certificates;

namespace EmployeeManagement
{
    internal class Program
    {
        public static List<Employee> Employees = new List<Employee>();
        public static List<Task> Tasks = new List<Task>();

        public static void Main(string[] args)
        {
            var utility = new Utility();
            var employeeManager = new EmployeeManager();
            var taskManager = new TaskManager();
            while (true)
            {
                Console.WriteLine("Available options: \n1-Add employee \n2-Add Task \n3-Import EmployeeList" +
                " \n4-Import TaskList \n5-Schedule Tasks \n6-Display Log \n7-Export EmployeeList \n8-Import TaskList \n9-Exit");
                switch (utility.GetInteger())
                {
                    case 1:
                        Employees = employeeManager.AddEmployee(Employees);
                        break;
                    case 2:
                        Tasks=taskManager.AddTask(Tasks);
                        break;
                    case 3:
                        employeeManager.ImportEmployeeList(Employees);
                        break;
                    case 4:
                        taskManager.ImportTaskList(Tasks);
                        break;
                    case 5:
                        var taskScheduler = new TaskScheduler();
                        taskScheduler.ScheduleTask(Tasks, Employees);
                        break;
                    case 6:
                        var logger = new Logger();
                        logger.DisplayLog();
                        break;
                    case 7:
                        employeeManager.ExportEmployeeDetails(Employees);
                        break;
                    case 8:
                        taskManager.ExportTaskDetails(Tasks);
                        break;
                    case 9:
                        return;
                    default:
                        Console.WriteLine("Enter only available options");
                        break;
                }
            }
        }
    }
}