﻿using ConsoleTables; 

namespace EmployeeManagement
{
    /// <summary>
    /// Contains methods to schedule the tasks
    /// </summary>
    internal class TaskScheduler
    {
        private Utility _utility = new Utility();
        private Logger _logger = new Logger();
        public Dictionary<Task,List<Employee>> TaskSchedule = new Dictionary<Task, List<Employee>>();
        public void ScheduleTask(List<Task> tasks, List<Employee> employees)
        {
           List<Task> sortedTaskList = tasks.OrderBy(t => t.DeadLine).ToList();
           foreach (var task in sortedTaskList)
            {
                List<Employee> employeeList = new List<Employee>();
               foreach(var employee in employees)
                {
                    if(employee.Availability==true&& employee.Skills==task.SkillsRequired&&task.RequiredHours>0)
                    {
                        if(employee.WorkingHours>task.RequiredHours)
                        {
                            employee.WorkingHours = employee.WorkingHours-task.RequiredHours;
                            employeeList.Add(employee);
                        }
                        if(employee.WorkingHours<task.RequiredHours)
                        {
                            employeeList.Add(employee);
                            task.RequiredHours = task.RequiredHours - employee.WorkingHours;
                        }
                        employee.Availability = false;
                        _logger.LogMessage($"Scheduled {task.Id} {DateTime.Now}");
                        continue;
                    }
                }
                TaskSchedule.Add(task, employeeList);
            }
            DisplayTaskSchedule();
        }
        public void DisplayTaskSchedule()
        {
            foreach (var task in TaskSchedule)
            {
                Console.WriteLine($"\n{task.Key.Id}:");
                foreach (var employee in task.Value)
                {
                    Console.Write($"{employee.Name} ");
                }
            }
        }
        public void ExportTaskSchedule()
        {
            var Table = new ConsoleTable("Task Id","DeadLine", "Employees");
            foreach (var task in TaskSchedule)
            {
                string employees= task.Value.ToString();
                Table.AddRow(task.Key.Id, task.Key.DeadLine,employees);
            }
            Console.WriteLine("Enter file path to export the content:");
            string filePath = _utility.GetValidFilePath();
            using (var writer = new StreamWriter(filePath))
            {
                writer.Write(Table);
            }
        }
    }
}